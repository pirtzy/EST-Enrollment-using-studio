# Copyright (c) 2022 Arista Networks, Inc.
# Use of this source code is governed by the Apache License 2.0
# that can be found in the COPYING file.

from typing import List, Dict
from cloudvision.cvlib import ActionFailed

cert = ctx.action.args.get("certificate")
filename = ctx.action.args.get("filename")


cert = cert.replace(" ", "")
cert = cert.replace("-----BEGINCERTIFICATE-----", "\r\n-----BEGIN CERTIFICATE-----\r\n")
cert = cert.replace("-----ENDCERTIFICATE-----", "\r\n-----END CERTIFICATE-----\r\n")

cmds = [
    "enable",
    {"cmd": f"copy terminal: file:{filename}", "input": cert},
    {"cmd": f"copy file:{filename} certificate:"},

]
cmdResponses: List[Dict] = ctx.runDeviceCmds(cmds)
# Iterate through the list of responses for the commands, and if an error occurred in
# any of the commands, raise an exception
# Only consider the first error that is encountered
# as following commands require previous ones to succeed
errs = [resp.get('error') for resp in cmdResponses if resp.get('error')]
if errs:
    raise ActionFailed(f"Copying of cert to {filename} failed with: {errs[0]}")
